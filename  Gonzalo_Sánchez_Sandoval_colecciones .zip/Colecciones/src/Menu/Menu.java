package Menu;

import Persona.Persona;

public class Menu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Lista lista = new Lista();
		
		for(int i=0;i<1000;i++){
			lista.lp.add(new Persona(i,"Persona"+i, );}
	}

}
