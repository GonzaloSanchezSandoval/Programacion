package Menu;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import Persona.Persona;

public class Lista {
	List<Persona> lp = new ArrayList<Persona>();
	private int idPersona;
	
	public Lista(int idPersona){
		this.idPersona = idPersona;
	
		}
	


}
