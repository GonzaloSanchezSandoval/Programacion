package Ejercicio2;

import java.util.Scanner;

public class moderadores extends Usuarios {

	public moderadores(int num_mensajes, String correo, String nick) {
		super (num_mensajes,correo, nick);
	}
	
	private int post_papelera;
	
	public void incrementar(int getnum_mensajes) {
		getnum_mensajes++;
	}
	
	public int getpost_papelera() {
		return post_papelera;
	}

	public void setpost_papelera(int post_papelera) {
		this.post_papelera = post_papelera;
	}

	public void decrementar(int getnum_mensajes) {
		getnum_mensajes--;
	}
	
	
	public void incrementar_papelera(int getpost_papelera) {
		getpost_papelera++;
	}
	
	public void modificar(String correo) {
		System.out.println("Por favor escriba el nuevo correo ");
		Scanner esc =new Scanner(System.in);
		String correo_nuevo =esc.next();
		correo_nuevo=correo;
	}
	
	
}
