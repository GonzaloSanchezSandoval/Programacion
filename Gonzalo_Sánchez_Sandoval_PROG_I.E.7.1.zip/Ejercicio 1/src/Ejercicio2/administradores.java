package Ejercicio2;

import java.util.Scanner;

public class administradores extends Usuarios{

	public administradores(int num_mensajes, String correo, String nick) {
		super(num_mensajes, correo, nick);
	
	}
	
	private int post_papelera;
	
	private int baneados;

	public int getPost_papelera() {
		return post_papelera;
	}

	public void setPost_papelera(int post_papelera) {
		this.post_papelera = post_papelera;
	}


	public int getBaneados() {
		return baneados;
	}

	public void setBaneados(int baneados) {
		this.baneados = baneados;
	}

	public void incrementar(int getnum_mensajes) {
		getnum_mensajes++;
	}
	
	public void decrementar(int getnum_mensajes) {
		getnum_mensajes--;
	}
	
	
	public void incrementar_papelera(int getpost_papelera) {
		getpost_papelera++;
	}
	
	public void modificar(String correo) {
		System.out.println("Por favor escriba el nuevo correo ");
		Scanner esc =new Scanner(System.in);
		String correo_nuevo =esc.next();
		correo_nuevo=correo;
	}
	
	public void cambiar_nick(String nick) {
		System.out.println("Por favor escriba el nuevo nick ");
		Scanner esc =new Scanner(System.in);
		String nick_nuevo =esc.next();
		nick_nuevo=nick;
	}
	
	public void incrementar_baneados(int baneados) {
		baneados++;
	}
}
