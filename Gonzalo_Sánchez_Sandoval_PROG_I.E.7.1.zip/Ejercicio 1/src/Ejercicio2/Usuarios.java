package Ejercicio2;

import java.util.Scanner;

public abstract class Usuarios {

	
	private int num_mensajes;
	

	public Usuarios(int num_mensajes, String correo, String nick) {
		
	}

	public int getNum_mensajes() {
		return num_mensajes;
	}

	public void setNum_mensajes(int num_mensajes) {
		this.num_mensajes = num_mensajes;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getNick() {
		return nick;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	private String correo, nick;
	
	public void incrementar(int num_mensajes) {
		num_mensajes++;
	}
	
	public void decrementar(int num_mensajes) {
		num_mensajes--;
	}
	
	public void modificar(String correo) {
		System.out.println("Por favor escriba el nuevo correo ");
		Scanner esc =new Scanner(System.in);
		String correo_nuevo =esc.next();
		correo_nuevo=correo;
	}
}
