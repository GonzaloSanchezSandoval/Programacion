package Ejercicio2;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		moderadores mod = new moderadores(0, null, null);
		
		administradores admin = new administradores(0, null, null);
		
		int n1,n2;
		
		
		System.out.println("Elija que tipo de cuenta va a crear: "
				+ " 1- Moderador "
				+ " 2- Administrador "
				+ " Pulse cualquier otro numero para salir del programa ");
		
		Scanner esc= new Scanner(System.in);
		n1=esc.nextInt();
		
		if(n1==1) {
			
			System.out.println(" Nickname: ");
			String nick= esc.next();
			mod.setNick(nick);
			
			
			System.out.println(" Correo: ");
			String correo= esc.next();
			mod.setCorreo(correo);
			
			System.out.println("Su cuenta ha sido creada: "+ nick +" "+correo);
			
			System.out.println("Mensajes: "+mod.getNum_mensajes() +" "+" Papelera: "+mod.getpost_papelera());
		do {	
			System.out.println("�Que desea hacer ahora?"
					+ " 1- Recibir correo "
					+ " 2- Enviar un correo a la papelera "
					+ " 3- Cambiar su correo actual ");
			
			n2=esc.nextInt();
			
			if(n2==1) {
				
				mod.incrementar(mod.getNum_mensajes());
			}
			if(n2==2) {
				mod.decrementar(mod.getNum_mensajes());
				mod.incrementar_papelera(mod.getpost_papelera());
			}
			
			if(n2==3) {
				System.out.println("Introduzca su nuevo correo");
				 correo= esc.next();
				mod.setCorreo(correo);
			}
				System.out.println("Su cuenta actual: "+ nick +" "+correo);
			
			System.out.println("Mensajes: "+mod.getNum_mensajes() +" "+" Papelera: "+mod.getpost_papelera());
			
		}while(n2==1||n2==2||n2==3);
			
		}
		
			if(n1==2) {
			
			System.out.println(" Nickname: ");
			String nick= esc.next();
			admin.setNick(nick);
			
			
			System.out.println(" Correo: ");
			String correo= esc.next();
			admin.setCorreo(correo);
			
			System.out.println("Su cuenta ha sido creada: "+ nick +" "+correo);
			
			System.out.println("Mensajes: "+admin.getNum_mensajes() +" "+" Papelera: "+admin.getPost_papelera()+" "+" Baneos: "+admin.getBaneados());
			
			do {	
				System.out.println("�Que desea hacer ahora?"
						+ " 1- Recibir correo "
						+ " 2- Enviar un correo a la papelera "
						+ " 3- Cambiar su correo actual "
						+ " 4- Banear una cuenta "
						+ " 5- Cambiar nombre de la cuenta");
				
				n2=esc.nextInt();
				
				if(n2==1) {
					
					admin.incrementar(admin.getNum_mensajes());
				}
				if(n2==2) {
					admin.decrementar(admin.getNum_mensajes());
					admin.incrementar_papelera(admin.getPost_papelera());
				}
				
				if(n2==3) {
					
					System.out.println("Introduzca su nuevo correo");
					correo= esc.next();
					admin.setCorreo(correo);
				}
					System.out.println("Su cuenta actual: "+ nick +" "+correo);
				
				
				if(n2==4) {
					int baneados = 0;
					admin.incrementar_baneados(baneados);
				}
				if(n2==5) {
					System.out.println("Introduzca su nuevo Nick");
					nick= esc.next();
					admin.setNick(nick);
				}

				System.out.println("Mensajes: "+admin.getNum_mensajes() +" "+" Papelera: "+admin.getPost_papelera());
				
			}while(n2==1||n2==2||n2==3||n2==4||n2==5);
		}
	}

}
