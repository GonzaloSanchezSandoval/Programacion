package Ejercicio1;

public class CuentaCorriente extends Cuenta{

	
	
	public CuentaCorriente(Persona Cliente, Long numerocuenta) {
		super(Cliente, numerocuenta);
	
	}

	private double saldo_inicial=0;
	
	public double getSaldo_inicial() {
		return saldo_inicial;
	}


	public void setSaldo_inicial(double saldo_inicial) {
		this.saldo_inicial = saldo_inicial;
	}


	public void retirar() {
	
		
	}

	
	void actualizarSaldo() {
		
		
	}
	
	double interes_fijo=0.15;
	
	
	



	public String toString(String nombre, String apellido,String cadena) {
		
		return cadena = "Nombre "+ nombre+ "Apellido "+ apellido;
		
	}

	

}
