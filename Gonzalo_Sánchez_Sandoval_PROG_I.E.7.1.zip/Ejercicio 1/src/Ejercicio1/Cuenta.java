package Ejercicio1;



public abstract class Cuenta {

	
	Long numerocuenta; 
	
	double saldo;
	
	private Persona Cliente;
	
	public Long getNumerocuenta() {
		return numerocuenta;
	}

	public void setNumerocuenta(Long numerocuenta) {
		this.numerocuenta = numerocuenta;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public Persona getCliente() {
		return Cliente;
	}

	public void setCliente(Persona cliente) {
		Cliente = cliente;
	}

	public Cuenta (Persona Cliente, Long numerocuenta){
		
	}
	
		public  void Ingresar(double cantidad) {
			saldo+=cantidad;
		}
	
		public abstract void retirar();
		
		abstract void actualizarSaldo();
			
		
		
		
	
	
	}
	
	