package Ejercicio1;

import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Random;


public class Men� {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int n1 = 0,n2 = 0;
		Long numerocuenta = null;
		Persona per =new Persona();
		CuentaCorriente Cu_co= new CuentaCorriente(per, numerocuenta);

		
		System.out.println("Bienvenido por favor elija que tipo de cuenta desea: "
				+ " 1- Cuenta corriente"
				+ " 2- Cuenta ahorro "
				+ " Pulse cualquier otro numero para salir del programa");
		Scanner esc= new Scanner(System.in);
		n1=esc.nextInt();
		
		
if(n1==1) {
			
			System.out.println(" Para crear una cuenta corriente introduzca sus datos, por favor ");
			
			System.out.println("Introduzca su nombre ");
			
			String Nombre=esc.nextLine();
			per.setNombre(Nombre);
			
			System.out.println("Introduzca sus apellidos");
			
			String Apellidos=esc.nextLine();
			per.setApellido(Apellidos);
			
			System.out.println("Introduzca su NIF");
			
			String NIF=esc.nextLine();
			per.setNIF(NIF);
			
			Random r = new Random();
			 numerocuenta = (long) r.nextInt(999999); 
			
			System.out.println("Los datos de su cuenta ser�n: " +Nombre +Apellidos +" NIF: " + NIF +" Numero de cuenta: " +numerocuenta);
			
			System.out.println("Su saldo inicial es: " +Cu_co.getSaldo_inicial());
			
			do {
			System.out.println(" �Qu� desea hacer? "
					+ " 1- Ingresar saldo "
					+ " 2- Retirar saldo "
					+ " Pulse cualquier otro numero para salir del programa ");
			
					n2=esc.nextInt();
				
					
				if(n2==1) {
					
					int Ingreso;
					System.out.println(" �Cu�nto desea ingresar? ");
					Ingreso=esc.nextInt();
					
					Cu_co.saldo=Cu_co.saldo+Ingreso;
				}
				
					
					
					
					
					
				
				
			}while(n2==1 || n2==2);
		
					
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
}

	


