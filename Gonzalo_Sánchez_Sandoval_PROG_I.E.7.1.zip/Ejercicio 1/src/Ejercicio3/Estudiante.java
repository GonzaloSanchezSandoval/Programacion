package Ejercicio3;

public class Estudiante extends Persona{

	private String ID_Estudiante;
	
	public Estudiante() {
	}
	
	public void Estudiante(String ID_Estudiante) {
	}

	public String getID_Estudiante() {
		return ID_Estudiante;
	}

	public void setID_Estudiante(String iD_Estudiante) {
		ID_Estudiante = iD_Estudiante;
	}
	
	public String toString() {
		return ID_Estudiante ;
		
	}
}
