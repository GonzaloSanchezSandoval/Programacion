package Ejercicio3;

public class Lista {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Estudiante alumnos = new Estudiante();
		
		Profesor profesor1 = new Profesor();
		
		
		System.out.println("Lista de alumnos");
		alumnos.toString();
		
		
		
		System.out.println("Lista de Profesores");
		profesor1.toString();
		
	}

}
