package Ejercicio3;

public abstract class Persona {

	Direccion dir = new Direccion();
	
	
	private String Nombre;
	private String apellidos;
	private String NIF;
    
    public interface Humano {
    	
    	public void identificate();
    }
}
