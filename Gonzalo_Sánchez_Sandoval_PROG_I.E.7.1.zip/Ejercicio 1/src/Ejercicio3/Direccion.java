package Ejercicio3;

import Ejercicio1.Persona;

public class Direccion {

	
	private String calle, ciudad, pa�s;
	private int CP;
	public String getCalle() {
		return calle;
	}
	public void setCalle(String calle) {
		this.calle = calle;
	}
	public String getCiudad() {
		return ciudad;
	}
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}
	public String getPa�s() {
		return pa�s;
	}
	public void setPa�s(String pa�s) {
		this.pa�s = pa�s;
	}
	public int getCP() {
		return CP;
	}
	public void setCP(int cP) {
		CP = cP;
	}
	
	
		
		
	    
		
	
}
