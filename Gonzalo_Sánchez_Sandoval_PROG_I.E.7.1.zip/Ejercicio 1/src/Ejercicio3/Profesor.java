package Ejercicio3;

public class Profesor extends Persona{

	Direccion dir = new Direccion();
	private String despacho;

	public String getDespacho() {
		return despacho;
	}

	public void setDespacho(String despacho) {
		this.despacho = despacho;
	}
	
	public Profesor() {
		
	}
	
	public void Profesor(String despacho) {
		
	}
	
	public String toString() {
		String mensaje="El despacho del profesor es:"+despacho;
		return mensaje;
	
		
	}
	
}
