package Ejercicio4;

public class libros extends Textos{

	private String prestado;

	public String getPrestado() {
		return prestado;
	}

	public void setPrestado(String prestado) {
		this.prestado = prestado;
	}
}
