package Ejercicio1;

public class CuentaAhorro extends Cuenta {

	
	public CuentaAhorro(Persona Cliente, Long numerocuenta) {
		super(Cliente, numerocuenta);
	
	}


	


	
	public void retirar() {
	
		
	}


	
	void actualizarSaldo() {
	
		
	}
	
		private double saldo_minimo;
	
	
		
		
		
	public String toString(String nombre, String apellido,String cadena) {
		
		return cadena = "Nombre "+ nombre+ "Apellido "+ apellido;
		
	}






	public double getSaldo_minimo() {
		return saldo_minimo;
	}






	public void setSaldo_minimo(double saldo_minimo) {
		this.saldo_minimo = saldo_minimo;
	}
}
