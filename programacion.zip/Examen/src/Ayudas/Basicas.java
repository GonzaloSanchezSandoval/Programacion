package Ayudas;

import java.util.Scanner;

public class Basicas {

	
	
	//Para usar el Scanner 
	
	Scanner esc=new Scanner(System.in);
	n1=esc.next();
	
	//Crear matriz
	
	String matriz [] [] = {};
	int matriz [] []=new matriz [][] ;
	
	
	//Puntos de silla
	for(int a=0; a<4;a++) {
		
		for(int b=0;b<4;b++) {
			
			if (Matriz[a][b]>max_fila[a]) {
				max_fila[a]=Matriz[a][b];
				
				if (Matriz[a][b]<min_col[b]) {
					min_col[b]=Matriz[a][b];
					
				}
				
			}
			
			if(max_fila[a]==min_col[b]) {
				System.out.println("Punto de silla en la posicion: " +a+ "," +b);
			}
		}
		
		
	}
	
	//Factorial 
	do {
	  factorial=factorial*numero;
	  numero--;
	  System.out.println(df.format(factorial));
	}while ( numero!=0);
	
	
	//Fibonacci
	
    
    System.out.print(fibo1 + " ");
    for(int i=2;i<=numero;i++){
         System.out.print(fibo2 + " ");
         fibo2 = fibo1 + fibo2;
         fibo1 = fibo2 - fibo1;
    }
    System.out.println();

	
	
}
