package Ejercicio15;

import java.util.Scanner;

public class Ejercicio15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		  Scanner sc = new Scanner(System.in);
	        int numero,fibo1=1,fibo2=1;
	        do{
	            System.out.print("Introduce la cantidad de numeros deseas que se muestren en pantalla: ");
	            numero = sc.nextInt();
	        }while(numero<=1);
	        System.out.println("Los " + numero + " primeros t�rminos de la serie de Fibonacci son:"); 

	        

	        
	        System.out.print(fibo1 + " ");
	        for(int i=2;i<=numero;i++){
	             System.out.print(fibo2 + " ");
	             fibo2 = fibo1 + fibo2;
	             fibo1 = fibo2 - fibo1;
	        }
	        System.out.println();
}
}
