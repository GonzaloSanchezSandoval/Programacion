package Ejercicio8;

import java.util.StringTokenizer;
import java.util.Vector;

public class Ejercicio8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		String frase="Jose Carlos \\n 8.5 \\n Roberto \\n 4.9 \\n Pedro \\n 3.8 \\n Jorge \\n 6.3";
		
		StringTokenizer tokens= new StringTokenizer(frase, "\\n");
		
		do {
			
			tokens.nextToken();
			
			Vector <String> vector = new Vector<String>();
			
			vector.add(tokens.nextToken());
			
			System.out.println(vector);
			
		}while(tokens.hasMoreTokens());
		 
		
		 }
		
				
			
		      
	}


