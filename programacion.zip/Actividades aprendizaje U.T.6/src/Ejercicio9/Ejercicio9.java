package Ejercicio9;

import java.util.Scanner;

public class Ejercicio9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int n1,inverso=0,aux,cifra;
		
		do {
		System.out.println("Por favor introduzca un numero entero mayor que 10 ");
		Scanner esc= new Scanner(System.in);
		n1 = esc.nextInt();
		
		}while(n1<10);
		
		
		  aux = n1;
	        while (aux!=0){
	            cifra = aux % 10;
	            inverso = inverso * 10 + cifra;
	            aux = aux / 10;
	        }
	 
	        if(n1 == inverso){
	            System.out.println("Es capicua");
	        }else{
	            System.out.println("No es capicua");
	        }
		
		
		
	}

}
