package Ejercicio3;

public class Ejercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String frase="la casa es aquella";
		
		
				System.out.println(frase);
			
			System.out.println("Eliminamos los espacios"); 
			
			frase=frase.replaceAll(" ", "");
		
		System.out.println(frase);
		
	}

}
