package Ejercicio14;

import java.text.DecimalFormat;

public class Ejercicio14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		DecimalFormat df = new DecimalFormat("#.00");
		double factorial=1,numero=30;
		
		while ( numero!=0) {
			  factorial=factorial*numero;
			  numero--;
			  System.out.println(df.format(factorial));
			}
		
		
	}

}
