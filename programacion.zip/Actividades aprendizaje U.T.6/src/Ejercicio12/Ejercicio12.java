package Ejercicio12;

import java.util.Scanner;

public class Ejercicio12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String n1;
		
		String matriz [] [] = {};
		
		for(int x=0;x==10;x++) {
			
			System.out.println("Por favor escriba una palabra para introducir en la sopa de letras ");
			Scanner esc=new Scanner(System.in);
			n1=esc.next();
			
		}
		
		
		
		for(int i=0;i<matriz.length;i++) {
			
			for(int j=0; j<matriz.length;j++) {
				
				
			}
		}
		
	}

}
