package Metodo8;

import java.text.DecimalFormat;

public class factorial {

	public factorial() {
		DecimalFormat df = new DecimalFormat("#.00");
		double factorial=1,numero=30;
		
				do {
			  factorial=factorial*numero;
			  numero--;
			  System.out.println(df.format(factorial));
			}while ( numero!=0);
		
	}
}
