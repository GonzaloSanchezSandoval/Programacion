package Metodo6;

public class Contar {
	
	public  Contar(){
 String Contar = ("la casa azul esta encima de la monta�a");
		 
		 System.out.println(Contar);
		 
		 int contador=0;
		 
		 for(int i=0;i<Contar.length();i++) {
			 
			 if((Contar.charAt(i)=='a')||(Contar.charAt(i)=='e')||(Contar.charAt(i)=='i')||(Contar.charAt(i)=='o')||(Contar.charAt(i)=='u')) {
				 
				 contador++;
			 }
			 
		 }
		 System.out.println("El numero de vocales en la oraci�n es "+contador);
	}

	}

