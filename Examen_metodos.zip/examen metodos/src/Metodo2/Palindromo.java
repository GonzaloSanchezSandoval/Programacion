package Metodo2;

public class Palindromo {

	
	public  Palindromo() {
		String frase="la casa es aquella";
		 frase = frase.replace(" ", "");
        frase=frase.replace(",", "");
        frase=frase.replace(".", "");
        System.out.print(frase);
        int fin = frase.length()-1;
        int ini=0;
        boolean espalin=true;
        
        while(ini < fin){
            if(frase.charAt(ini)!=frase.charAt(fin)){
                espalin=false;
            }
        ini++;
        fin--;
        }
        if(espalin)
            System.out.print(" Es palindromo.");
        else
            System.out.print(" No es palindromo.");
        
	}
}
