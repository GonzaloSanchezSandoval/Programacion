package Metodo9;

import java.util.StringTokenizer;

public class Tokenizer {

	public Tokenizer(){
		String frase = null;
		StringTokenizer tokens= new StringTokenizer(frase, "\\n");
	}
}
