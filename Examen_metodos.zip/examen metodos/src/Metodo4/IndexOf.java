package Metodo4;

import java.util.Scanner;

public class IndexOf {

		public IndexOf() {

		System.out.println("�Que palabra deseas buscar en el String?");
		Scanner esc = new Scanner(System.in);
		String palabra = esc.next();
		
		String frase="la casa esta all�";
		int resultado = frase.indexOf(palabra);
		
		if(resultado != -1) {
			System.out.println("La palabra se encuentra en la frase ");
		}
		
		else   {
			
		}System.out.println("La palabra no se encuentra en la frase ");
		
	}
	}

