package Metodo3;

public class Punto_Silla {

	
	public  Punto_Silla() {
		 
		        int max_fila[]= {-999,-999,-999,-999};
				int min_col[]= {999,999,999,999};
				int x = 0, y = 0;
				
				int Matriz [][]= {{1,2,6,0},{4,5,7,8},{1,10,8,3},{8,7,9,5}};
				
				for(int a=0; a<3;a++) {
					
					for(int b=0;b<3;b++) {
						
						if (Matriz[a][b]>max_fila[a]) {
							max_fila[a]=Matriz[a][b];
							
							if (Matriz[a][b]<min_col[b]) {
								min_col[b]=Matriz[a][b];
								
							}
							
						}
						
						if(max_fila[a]==min_col[b]) {
							System.out.println("Punto de silla en la posicion: " +a+ "," +b);
						}
					}
				}
	}
		
}
