package Metodo7;

import java.util.Scanner;

public class Fibonacci {

	
public Fibonacci(){
	Scanner sc = new Scanner(System.in);
    int numero,fibo1=1,fibo2=1;
    do{
        System.out.print("Introduce la cantidad de numeros deseas que se muestren en pantalla: ");
        numero = sc.nextInt();
    }while(numero<=1);
    System.out.println("Los " + numero + " primeros t�rminos de la serie de Fibonacci son:"); 

    //El programa te pedir� la cantidad de numeros que quieres que aparezca en pantalla, entonces generar� a traves de fibonacci esa misma cantidad de valores

    
    System.out.print(fibo1 + " ");
    for(int i=2;i<=numero;i++){
         System.out.print(fibo2 + " ");
         fibo2 = fibo1 + fibo2;
         fibo1 = fibo2 - fibo1;
    }
    System.out.println();
}
    
}
