package MetodoScann;

import java.util.Scanner;

public class MetodoSca {

	public MetodoSca() {
		Scanner esc=new Scanner(System.in);
		String n1 = esc.next();
	}
}
