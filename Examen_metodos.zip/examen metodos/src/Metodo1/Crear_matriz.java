package Metodo1;



public class Crear_matriz {

	
	
	public Crear_matriz()
	{
		String matriz1 [] [] = {};
	}
	
	
	
}
