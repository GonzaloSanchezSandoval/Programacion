package Ejercicio2;

import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String frase = "la casa de mar�a es aquella";
		
		int la = 0;
		int casa = 0;
		int de = 0;
		int mar�a = 0;
		int es = 0;
		int aquella = 0;
		int n1;
		String n2;
		
		int arr []= {la,casa,de,mar�a,es,aquella };
		
		for(int i=0;i<=arr.length;i++) {
			
			System.out.println(" �Quieres cambiar la palabra actual? "
					+ " 1- S� "
					+ " 2- Pulsa cualquier otro numero para seguir a la siguiente palabra ");
			
			Scanner esc = new Scanner(System.in);
			n1 = esc.nextInt();
			
			if(n1==1) {
				
				System.out.println("Indique la palabra que quiere escribir");
				Scanner esc1 = new Scanner(System.in);
				n2 = esc1.next();
			}
			 
			
			System.out.println("La frase final es " );
			
		}
		
	}

}
