package Ejercicio1;

public class Ejercicio1 {

	
	 String Contar = ("la casa azul esta encima de la monta�a");
 
    public void contar(String cadena)
    {
        String vocales="aeiou";
        
        String a,e,i,o,u;
        
        
        arr[]= {a,e,i,o,u};
        
        int contador[]={0,0,0,0,0};
 
        
        for(int x=0;x<Contar.length();x++)
        {
            // recorremos las vocales para comparar con cada una de las letras
            for(int j=0;j<vocales.length();j++)
            {
                if(Contar.charAt(x)==vocales.charAt(j))
                {
                    // aumentamos el contador para la vocal encontrada
                    contador[j]++;
                }
            }
        }
 
        for(int i=0;i<vocales.length();i++)
        {
            System.out.println("Aparece la letra "+vocales.charAt(i)+": "+contador[i]+" veces");
        }
    }
 
}
